package com.example.laborator5_2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView textview;
    Button buttonOK;
    Button buttonCancel;
    // button buttonStart;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textview = (TextView) findViewById(R.id.textView);
        buttonOK = (Button) findViewById(R.id.buttonOK);
        buttonCancel = (Button) findViewById(R.id.buttonCancel);
        View.OnClickListener rez = new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                // по id определеяем кнопку, вызвавшую этот обработчик
                switch (v.getId()) {
                    case R.id.buttonOK:
                        // кнопка ОК
                        textview.setText("Нажата кнопка ОК");
                        break;
                    case R.id.buttonCancel:
                        // кнопка Cancel
                        textview.setText("Нажата кнопка Cancel");
                        break;
                }
            }
        };
        buttonOK.setOnClickListener(rez);
        buttonCancel.setOnClickListener(rez);
    }
}